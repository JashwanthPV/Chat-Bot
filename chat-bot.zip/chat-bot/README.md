# Chat-Bot
A voice chatbot that would be used to call customers to enquire about a product and get details along with comparison study of competitive products and if the customer decides to book an appointment with sales BOT its able to set up an appointment. Use Case is a car showroom either a new car or used car showroom. 
